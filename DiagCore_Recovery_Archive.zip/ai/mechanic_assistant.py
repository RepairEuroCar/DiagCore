def analyze_report(report: dict) -> str:
    dtc_list = report.get("dtc", [])
    vin = report.get("vin", "неизвестно")
    advice = f"VIN: {vin}\n\n"

    dtc_db = {
        "P0087": {
            "problem": "Низкое давление топлива",
            "causes": [
                "Неисправен топливный насос",
                "Засорён топливный фильтр",
                "Проблемы с регулятором давления",
                "Обратная магистраль заблокирована"
            ],
            "urgency": "Критично — возможен отказ запуска"
        },
        "P0100": {
            "problem": "Сбой цепи MAF (массового расходомера воздуха)",
            "causes": [
                "Повреждение датчика",
                "Коррозия или загрязнение контактов",
                "Обрыв или короткое замыкание в проводке"
            ],
            "urgency": "Желательно устранить — возможен перерасход топлива"
        }
    }

    for dtc in dtc_list:
        entry = dtc_db.get(dtc, None)
        if not entry:
            advice += f"DTC: {dtc}\nОписание отсутствует в базе.\n\n"
            continue

        advice += f"DTC: {dtc}\nПроблема: {entry['problem']}\n"
        advice += f"Срочность: {entry['urgency']}\n"
        advice += "Возможные причины:\n"
        for i, cause in enumerate(entry["causes"], 1):
            advice += f"{i}. {cause}\n"
        advice += "\n"

    if "freeze_frame" in report:
        advice += "Freeze Frame:\n"
        for k, v in report["freeze_frame"].items():
            level = f"{v} (в норме)"
            if k == "fuel_pressure" and v < 250:
                level = f"{v} (низкое давление)"
            elif k == "rpm" and v < 900:
                level = f"{v} (низкие обороты)"
            advice += f"- {k}: {level}\n"

    advice += "\nРекомендуется: провести осмотр системы в соответствии с приоритетами выше."
    return advice.strip()