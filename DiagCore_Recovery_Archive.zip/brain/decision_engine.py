class DecisionEngine:
    def __init__(self):
        self.rules = []

    def evaluate(self, event):
        description = event.get("description", "").lower()
        if "критическая ошибка" in description:
            return "Внимание: критическая ошибка. Необходима немедленная диагностика."
        elif "ошибка" in description:
            return "Обнаружена ошибка. Рекомендуется проверка."
        return "Событие зарегистрировано. Мониторинг продолжается."