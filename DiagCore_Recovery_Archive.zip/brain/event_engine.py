class EventEngine:
    def __init__(self):
        self.history = []

    def trigger_event(self, source, description, payload=None):
        event = {
            "source": source,
            "description": description,
            "payload": payload or {},
        }
        self.history.append(event)
        print(f"[EventEngine] Событие от {source}: {description}")
        if payload:
            print(f"  Данные: {payload}")