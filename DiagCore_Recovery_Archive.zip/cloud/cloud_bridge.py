from datetime import datetime

class TransferBridge:
    def __init__(self):
        self.inbox = {}  # ключ: mechanic_id, значение: список логов

    def send_report(self, driver_id: str, mechanic_id: str, report: dict, urgent: bool = False, eta: int = None):
        entry = {
            "from": driver_id,
            "timestamp": datetime.utcnow().isoformat(),
            "urgent": urgent,
            "eta_minutes": eta,
            "report": report
        }

        if mechanic_id not in self.inbox:
            self.inbox[mechanic_id] = []

        self.inbox[mechanic_id].append(entry)
        print(f"[BRIDGE] Лог от {driver_id} отправлен механику {mechanic_id} | срочно: {urgent} | ETA: {eta}")

    def get_inbox(self, mechanic_id: str):
        return self.inbox.get(mechanic_id, [])

    def clear_inbox(self, mechanic_id: str):
        self.inbox.pop(mechanic_id, None)