from fastapi import FastAPI, Request
from coremind.cloud.cloud_bridge import TransferBridge
from coremind.ai.mechanic_assistant import analyze_report

app = FastAPI()
bridge = TransferBridge()

@app.get("/api/mechanic/inbox/{mechanic_id}")
def get_mechanic_inbox(mechanic_id: str):
    return bridge.get_inbox(mechanic_id)

@app.post("/api/mechanic/assistant")
async def mechanic_assistant_endpoint(request: Request):
    payload = await request.json()
    report = payload.get("report", {})
    response = analyze_report(report)
    return {"response": response}