from aiogram import Bot, Dispatcher, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage
import os

BOT_TOKEN = os.getenv("DRIVER_BOT_TOKEN", "your_driver_bot_token_here")
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(bot, storage=MemoryStorage())

@dp.message_handler(commands=["start", "help"])
async def cmd_start(message: types.Message):
    await message.reply(
        "Привет! Я ассистент DiagCore для водителей. В дальнейшем я смогу:
"
        "- Проводить экспресс-диагностику
"
        "- Уведомлять о проблемах с машиной
"
        "- Отправлять логи механику

"
        "Ожидай обновлений!"
    )