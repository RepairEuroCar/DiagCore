from aiogram import Bot, Dispatcher, types
from aiogram.types import ParseMode
from aiogram.contrib.fsm_storage.memory import MemoryStorage
import aiohttp
import os

BOT_TOKEN = os.getenv("MECHANIC_BOT_TOKEN", "your_mechanic_bot_token_here")
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(bot, storage=MemoryStorage())

@dp.message_handler(commands=["start", "help"])
async def cmd_start(message: types.Message):
    await message.reply("Добро пожаловать в DiagCore Mechanic Bot. Используйте /inbox для входящих отчётов.")

@dp.message_handler(commands=["inbox"])
async def cmd_inbox(message: types.Message):
    mechanic_id = f"mech_{message.from_user.id}"
    url = f"http://localhost:8080/api/mechanic/inbox/{mechanic_id}"

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                data = await resp.json()
                if not data:
                    await message.reply("Нет входящих отчётов.")
                    return
                for entry in data:
                    urgent = "⚠️ СРОЧНО" if entry.get("urgent") else "Обычный визит"
                    report = entry.get("report", {})
                    msg = (
                        f"<b>{urgent}</b>\n"
                        f"<b>VIN:</b> {report.get('vin', '-') }\n"
                        f"<b>ETA:</b> {entry.get('eta_minutes')} мин\n"
                        f"<b>Ошибки:</b> {', '.join(report.get('dtc', []))}\n"
                        f"<b>Примечание:</b> {report.get('note', '-')}"
                    )
                    await message.reply(msg, parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.reply(f"Ошибка получения данных: {e}")