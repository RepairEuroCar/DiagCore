def generate_auto_response(manager):
    history = manager.get("history", [])
    last_event = history[-1] if history else "Нет истории."
    return (
        f"Здравствуйте! Я ваш персональный ассистент {manager['manager_name']}.\n"
        f"Последнее зарегистрированное событие: {last_event if isinstance(last_event, str) else 'данные получены.'}\n"
        f"Рекомендую проверить систему или связаться с техподдержкой, если проблема повторится."
    )