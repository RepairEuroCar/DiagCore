class SupportRegistry:
    def __init__(self):
        self.clients = {}

    def get_or_create_manager(self, client_id):
        if client_id not in self.clients:
            self.clients[client_id] = {
                "manager_name": f"Ассистент_{client_id[-4:]}",
                "history": [],
                "id": client_id
            }
        return self.clients[client_id]

    def log_interaction(self, client_id, message):
        manager = self.get_or_create_manager(client_id)
        manager["history"].append(message)