from fpdf import FPDF
from datetime import datetime

class MechanicPDF(FPDF):
    def header(self):
        self.set_font("Arial", "B", 12)
        self.cell(0, 10, "DiagCore — Отчёт по диагностике", ln=True, align="C")

    def footer(self):
        self.set_y(-15)
        self.set_font("Arial", "I", 8)
        self.cell(0, 10, f"Страница {self.page_no()}", 0, 0, "C")

    def add_report(self, vin, dtc_list, freeze_data, ai_advice):
        self.add_page()
        self.set_font("Arial", "", 11)
        self.cell(0, 10, f"VIN: {vin}", ln=True)
        self.cell(0, 10, f"Дата: {datetime.now().strftime('%Y-%m-%d %H:%M')}", ln=True)

        self.ln(5)
        self.set_font("Arial", "B", 12)
        self.cell(0, 10, "DTC-коды:", ln=True)
        self.set_font("Arial", "", 11)
        for code in dtc_list:
            self.cell(0, 10, f"- {code}", ln=True)

        self.ln(5)
        self.set_font("Arial", "B", 12)
        self.cell(0, 10, "Freeze Frame:", ln=True)
        self.set_font("Arial", "", 11)
        for k, v in freeze_data.items():
            self.cell(0, 10, f"- {k}: {v}", ln=True)

        self.ln(5)
        self.set_font("Arial", "B", 12)
        self.cell(0, 10, "Рекомендации AI:", ln=True)
        self.set_font("Arial", "", 11)
        for line in ai_advice.splitlines():
            self.multi_cell(0, 8, line)

def generate_pdf(filename, report):
    pdf = MechanicPDF()
    vin = report.get("vin", "не указано")
    dtc = report.get("dtc", [])
    freeze = report.get("freeze_frame", {})
    advice = report.get("ai_response", "Нет данных")
    pdf.add_report(vin, dtc, freeze, advice)
    pdf.output(filename)